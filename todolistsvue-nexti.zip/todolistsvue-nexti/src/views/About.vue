<template>
    <div class="about">
        <h1>Essa é a página de SOBRE</h1>
    </div>
</template>
